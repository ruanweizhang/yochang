define(['angularAMD'], function() {
  var core = angular.module('app.core', []);

  return core;

});
